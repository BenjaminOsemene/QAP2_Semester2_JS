
//Problem 1:
//wrote a JavaScript function called snake that takes a string value as input and 
//Returns the Lower Snake Case version of the string. 
//Trim leading and trailing whitespace from the input string.
//Replace all internal whitespace (spaces, tabs) and dots with underscores ('_').
//Convert all letters to lowercase.

 function snake(value) {
    value = value.trim();
    value = value.replace(/[ \t.]/g, '_').toLowerCase();
    return value;
 }

//checking that the function works
 console.log(snake('abc')); 
console.log(snake(' ABC ')); 
console.log(snake('ABC')); 
console.log(snake('A BC')); 
console.log(snake(' A bC  ')); 
console.log(snake('A   BC'));
console.log(snake('A.BC')); 
console.log(snake(' A..  B   C ')); 


//Problem 2: 
//Writing a function createVideo that takes src, width, and controls as parameters 
//Then  trims any leading or trailing whitespace from src 
//Add src attribute , including width attribute if it is an integer value.
// Add controls attribute if true.

function createVideo(src, width, controls) {
    src = src.trim(); 
    var videoElem = '<video '
    videoElem += 'src="' + src + '"';
    if (!isNaN(parseInt(width))) {
      videoElem += ' width="' + width + '"';
    }
    
    if (controls === true) {
      videoElem += ' controls';
    }
    
    videoElem += '></video>'; 
    
    return videoElem;
  }

//Checking that the function works.
console.log(createVideo('http://distribution.bbb3d.renderfarming.net/video/mp4/bbb_sunflower_1080p_60fps_normal.mp4', 500));



//Problem3:
//Extracting date from date string
//Writing a function parseDateString that takes value as parameter
// Providing error messages using throw method to throw  errors when incorrect value is passed.
    function parseDateString(value) {
        if (typeof value !== 'string' || !value) {
          throw new Error('Invalid');
        }
        let dateParts = value.split('-');
        if (dateParts.length !== 3) {
          throw new Error('Format invalid.Please provide valid format: YYYY-MM-DD');
        }
      
        let year = dateParts[0];
        let month = dateParts[1];
        let day = dateParts[2];

        if (year.length !== 4 || month.length !== 2 || day.length !== 2) {
          throw new Error('Invalid date format. Year, month, and day must have correct digits');
        }
      
        if (isNaN(year) || isNaN(month) || isNaN(day)) {
          throw new Error('Invalid date format. Year, month, and day must be numbers');
        }
        let yearNum = parseInt(year);
        let monthNum = parseInt(month);
        let dayNum = parseInt(day);
      
        if (monthNum < 1 || monthNum > 12) {
          throw new Error('Invalid month value');
        }
        if (dayNum < 1 || dayNum > 31) {
          throw new Error('Invalid day value');
        }
      
        let dateObj = new Date();
        dateObj.setFullYear(yearNum);
        dateObj.setMonth(monthNum - 1); 
        dateObj.setDate(dayNum);
      
        return dateObj;
      }
      
//Checking that the function works
let dateobj = parseDateString("2021-01-01");
console.log(dateobj); 
//let dateq = parseDateString('01-01-01')
//console.log(dateq);
//let dateqr = parseDateString('2021-01-1')
//console.log(dateqr);
//let dateqd = parseDateString(null)
//console.log(dateqd);



//Problem 4: 
//This creates toDateString function that accepts dateobj as parameter.
// Checks if what imputted is correct using "instanceof Date" and isNaN.
//Set year, month, and day  using methods.
//Format month and day using string.padStart.
//Returns date string in the format YYYY-MM-DD.
//Shows error with message if incorrect dateobj is passed using a try/catch method.

function toDateString(value) {
  try {
      if (!(value instanceof Date) || isNaN(value)) {
          throw new Error('Date is not valid');
      }

      let year = value.getFullYear();
      let month = String(value.getMonth() + 1).padStart(2, '0');
      let day = String(value.getDate()).padStart(2, '0');

      return `${year}-${month}-${day}`;
  } catch (error) {
      throw new Error('Date not valid: ' + error.message);
  }
}

//Checking if the function works by setting time zone to GMT.
try {
  let value = new Date('2021-01-29T00:00:00');
  console.log(toDateString(value));
} catch (error) {
  console.error(error.message); 
}



//Problem 5:
//Define normalizeCoord functioin with parameter value.
//Remove brackets and spaces.
//Splilt string into latitude and longitude using comma.
//Then parse latitude and longitude as floats.
// Checking if the parsed values are in the form (lat, lng).

function normalizeCoord(value) {
  value = value.replace(/[\[\]\s]/g, ''); 
  let [lat, lng] = value.split(',');
  let latitude = parseFloat(lat);
  let longitude = parseFloat(lng);

  if (latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180) {
    return `(${latitude}, ${longitude})`;
  } else {
    return 'Invalid coordinates';
  }
}
// Checking that the function works.
let c1 = "42.9755,-77.4369";
let c2 = "[-77.4369, 42.9755]";

console.log(normalizeCoord(c1)); 
console.log(normalizeCoord(c2)); 


//Problem:6 
//This defines formatCoords function taking  a list of coordinates
// Using normalizedCoord function to parse valid coordinates and 
//Define regular expression to match valid coordinates.
//Filter out invalid coordinates.
//Creating a format list of geographic coordinates.

function formatCoords(...values) {
  let validCoordinates = values.filter(value => {
      try {
          let [lat, lng] = normalizeCoord(value);
          return true;
      } catch (error) {
          return false;
      }
  }).map(value => `(${normalizeCoord(value).join(', ')})`);

  return `(${validCoordinates.join(', ')})`;
}

function normalizeCoord(value) {
  let regExp = /^ *\[? *(-?\d+\.\d+), *(-?\d+\.\d+) *\]?$/;
  let match = regExp.exec(value);
  if (!match) {
      throw new Error(`Invalid coordinate format: ${value}`);
  }
  let [, lat, lng] = match;
  return [lat, lng];
}
//Checking that the function works
console.log(formatCoords("42.9755,-77.4369", "[-62.1234, 42.9755]", "300,-9000"));



//Problem 7:
//Creating a function mimeFromFilename taking filename as a parameter using switch statement
//Returning MIME types file extensions
//Returning "application/octet-stream" If file extension does not exist 

function mimeFromFilename(filename) {
  let ext = filename.split('.').pop().toLowerCase();
  switch (ext) {
    case 'html':
    case 'htm':
      return 'text/html';
    case 'css':
      return 'text/css';
    case 'js':
      return 'text/javascript';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'gif':
      return 'image/gif';
    case 'bmp':
      return 'image/bmp';
    case 'ico':
    case 'cur':
      return 'image/x-icon';
    case 'png':
      return 'image/png';
    case 'svg':
      return 'image/svg+xml';
    case 'webp':
      return 'image/webp';
    case 'mp3':
      return 'audio/mp3';
    case 'wav':
      return 'audio/wav';
    case 'mp4':
      return 'video/mp4';
    case 'webm':
      return 'video/webm';
    case 'json':
      return 'application/json';
    case 'mpeg':
      return 'video/mpeg';
    case 'csv':
      return 'text/csv';
    case 'ttf':
      return 'font/ttf';
    case 'woff':
      return 'font/woff';
    case 'zip':
      return 'application/zip';
    case 'avi':
      return 'video/x-msvideo';
    default:
      return 'application/octet-stream'; 
  }
}

//Checking that the function works
console.log(mimeFromFilename('/User/Documents/readme.txt')); 
console.log(mimeFromFilename('index.html')); 
console.log(mimeFromFilename('image.jpg')); 
console.log(mimeFromFilename('script.js')); 



//Problem 8:
//This generateLicenseLink function taking parameters licenseCide and targetBlank
// Remove 'CC-' prefix and convert to lowercase
// Generate license text and link from license code placing formatted licencese code in URL
//Add target="_blank" to the link if targetBlank is true so that the url opens in a blank tab/window
//Return HTML link string

function generateLicenseLink(licenseCode, targetBlank = false) {
  let formatCode = licenseCode.replace('CC-', '').toLowerCase();
  let url = `https://creativecommons.org/licenses/${formatCode}/4.0/`;
  let linkText = '';
  switch (formatCode) {
    case 'by':
      linkText = 'Creative Commons Attribution License';
      break;
    case 'by-nc':
      linkText = 'Creative Commons Attribution-NonCommercial License';
      break;
    default:
      linkText = 'Unknown License';
      break;
  }
  let targetElem= targetBlank ? ' target="_blank"' : '';

  let htmlLink = `<a href="${url}"${targetElem}>${linkText}</a>`;
  
  return htmlLink;
}

// Testing that the function works
console.log(generateLicenseLink('CC-BY-NC')); 
console.log(generateLicenseLink('CC-BY')); 
console.log(generateLicenseLink('CC0', true));
console.log(generateLicenseLink('CC-BY-SA')); 
console.log(generateLicenseLink('CC-BY-ND')); 
console.log(generateLicenseLink('CC-BY-NC-SA')); 
console.log(generateLicenseLink('CC-BY-NC-ND')); 



//Problem 9:
//This problem requires creating a function called pureBool() taking a value.
//Then converting the value into a Boolean(true or false) based on rules:
//If the value is already a Boolean (true or false), return the value without conversion.
//If the value is one of the "true" type values (e.g., 'Yes', 'Oui', 't', 'TRUE', etc.), return true.
//If the value is one of the "false" type values (e.g., 'No', 'Non', 'f', 'FALSE', etc.), return false.
//If the value is none of the "true" or "false" values, throw an error with the error message 'invalid value'.
 
function pureBool(value) {
  if (typeof value === 'boolean') {
    return value; 
  }
  let valueLower = String(value).toLowerCase();
  let valuesTrue = ['yes', 'oui', 'o', 't', 'true', 'vrai', 'v', '1'];
  let valuesFalse = ['no', 'non', 'n', 'f', 'false', 'faux', '0'];
  if (valuesTrue.includes(valueLower)) {
    return true;
  }
  if (valuesFalse.includes(valueLower)) {
    return false;
  }
  throw new Error('invalid value');
}

// Checking that the function works
console.log(pureBool(true)); 
console.log(pureBool('Yes')); 
console.log(pureBool('NO')); 
//console.log(pureBool('invalid')); 



//Problem 9b:
//This problem uses try/catch method to handle errors thrown in pureBool() function
//Then creating three functions, every function to  checks if all values in the argument list are true, 
//Then any function checks if any value in the list is true
//Then none function checks if all values in the list are false.

function every(...values) {
  try {
    return values.every(value => pureBool(value) === true);
  } catch (error) {
    return true;
  }
}

function any(...values) {
  try {
    return values.some(value => pureBool(value) === true);
  } catch (error) {
    return true;
  }
}

function none(...values) {
  try {
    return values.every(value => pureBool(value) === false);
  } catch (error) {
    return false;
  }
}

//Checking that the functions work
console.log(every('Y', 'yes', 1)); 
console.log(any('Y', 'no', 1)); 
console.log(none('Y', 'invalid', 1)); 



//Problem 10:
//This involves writing function buildUrl() with parameters:query,order,count,license
//Validates parameters such as count,license, query, order .
//Returns formatted URL

function buildUrl(query, order, count, license) {
  if (count < 1 || count > 50) {
    throw new Error('Count is invalid must be between 1-50.');
  }

  let licensesValid = ['none', 'any', 'cc-by', 'cc-by-nc', 'cc-by-sa', 'cc-by-nd', 'cc-by-nc-sa', 'cc-by-nc-nd'];
  if (!licensesValid.includes(license)) {
    throw new Error('License is invalid must be one of: none, any, cc-by, cc-by-nc, cc-by-sa, cc-by-nd, cc-by-nc-sa, cc-by-nc-nd.');
  }

if (order !== 'ascending' && order !== 'descending') {
  throw new Error('Order is invalid must be either "ascending" or "descending".');
}

let encodedQuery = encodeURIComponent(query);

let url = `https://api.inaturalist.org/v2/observations?query=${encodedQuery}&count=${count}&order=${order}&license=${license}`;

  return url;
}

//Checking that the function works
try {
  let url = buildUrl('Monarch Butterfly', 'ascending', 25, 'cc-by');
  console.log(url); 
} catch (error) {
  console.error(error.message);
}
